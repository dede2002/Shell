#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    DIR *d;
    struct dirent *dir;
    char *path = "."; // Default to current directory

    if (argc > 1) {
        path = argv[1];
    }

    d = opendir(path);
    if (d) {
        while ((dir = readdir(d)) != NULL) {
            printf("%s \n", dir->d_name);
        }
        closedir(d);
    } else {
        perror("my_ls");
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
